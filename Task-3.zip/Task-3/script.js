//Task 3 
//Do the below programs in anonymous function and arrow function
//Print odd numbers in an array ----------------------------------------------------------------------
let style = "color: red; font-size: 20px ";
let input= "color:#423770;font-size:15px";
console.log("%cPrint odd numbers in an array", style)
console.log("%cInput [1, 2, 3, 4, 44, 32, 11, 25, 56]",input)
//1.anonymous function
console.log("1.anonymous function")
let array = [1, 2, 3, 4, 44, 32, 11, 25, 56]
let ans = [];
let display = 0;
let oddnumber = function (array) {
    for (let i in array) {
        if (array[i] % 2 == 0) {
            continue;
        }
        else {
            ans.push(array[i]);
        }
    }
    return ans;
}
display = oddnumber(array);
console.log(display)
display.length = 0;
//2.arrow function
console.log("2.Arrow function")
let arrow = (array) => {
    for (let i in array) {
        if (array[i] % 2 == 0) {
            continue;
        }
        else {
            ans.push(array[i]);
        }
    }
    return ans;
}
display = arrow(array);
console.log(display);
display.length = 0;
//Convert all the strings to title caps in a string array-----------------------------------------------
console.log("%cConvert all the strings to title caps in a string array", style)
array = ["gaurav", "rakesh", "nilima", "sahil", "medha"]
console.log("%cInput ['gaurav', 'rakesh', 'nilima', 'sahil', 'medha']",input)
//1.anonymous function
console.log("1.anonymous function")
let string_caps = function (array) {

    for (let i in array) {
        array[i] = array[i].charAt(0).toUpperCase() + array[i].slice(1);
    }
    return array;
}
display = string_caps(array);
console.log(display)
display.length = 0;
//2.Arrow function
console.log("2.Arrow function")
array1 = ["gaurav", "rakesh", "nilima", "sahil", "medha"]
let string_caps1 = (array1) => {
    for (let i in array1) {
        array1[i] = array1[i].charAt(0).toUpperCase() + array1[i].slice(1);
    }
    return array1;
}
display = string_caps1(array1)
console.log(display)
display.length = 0;
//Sum of all numbers in an array
console.log("%cInput [1,2,3,4,5,6,7]",input)
console.log("%cSum of all numbers in an array", style)
//1.anonymous function
console.log("1.anonymous function")
let third_array = [1, 2, 3, 4, 5, 6, 7]
let sum_array = function () {
    let addition = third_array.reduce(function (num, initial) {
        return num + initial
    }, 0)
    return addition;
}
console.log(sum_array());
//2.arrow function
console.log("2.Arrow function")
let sum_array_arrow = () => {
    let addition_1 = third_array.reduce(function (num, initial) {
        return num + initial
    }, 0)
    return addition_1;
}
console.log(sum_array_arrow());
//Return all the prime numbers in an array
console.log("%cReturn all the prime numbers in an array", style)
console.log("%cInput [1, 2, 34, 45, 67, 3, 5]",input)
//1 anonymous function
console.log("1.anonymous function")
let prime_array = [1, 2, 34, 45, 56, 67, 3, 5]
ans = [];
let prime_function = function (prime_array) {
    for (let i in prime_array) {
        if (prime_array[i] == 1) {
            continue;
        }
        else {
            let j = 2;
            let flag = 0;
            while (j < (prime_array[i] / 2)) {
                j = j + 1

                if (prime_array[i] % j == 0) {
                    flag = 1;
                    break;
                }
                else {
                    continue;
                }

            }
            if (flag == 0) {
                ans.push(prime_array[i])
            }
        }
    }
    return ans;
}
console.log(prime_function(prime_array));
//2.arrowfunction
console.log("2.arrow function")
prime_array_1 = [1, 2, 34, 45, 56, 67, 3, 5]
ans = [];
let prime_function_arrow = (prime_array) => {
    for (let i in prime_array) {
        if (prime_array[i] == 1) {
            continue;
        }
        else {
            let j = 2;
            let flag = 0;
            while (j < (prime_array[i] / 2)) {
                j = j + 1
                if (prime_array[i] % j == 0) {
                    flag = 1;
                    break;
                }
                else {
                    continue;
                }

            }
            if (flag == 0) {
                ans.push(prime_array[i])
            }
        }
    }
    return ans;
}
console.log(prime_function_arrow(prime_array_1));
//Return all the palindromes in an array-------------------------------------------------------------------------
console.log("%cReturn all the palindromes in an array", style)
console.log("%cInput ['Pranil','NAN','101',111,'nil']",input)
//1. anonymous function
console.log("anonymous function")
let array_palindrom = ["Prani", "NAN", "101", 111, "nil"]
let store_reverse;
ans = [];
let Is_panlindrom = function (array_palindrom) {
    for (let i in array_palindrom) {
        store_reverse = String(array_palindrom[i]).split("").reverse().join("");
        if (array_palindrom[i] == store_reverse) {
            ans.push(store_reverse)
        }
        else {
            continue;
        }
    }
    return ans;
}
console.log(Is_panlindrom(array_palindrom))
//2.arrow function
console.log("2.arrow function")
let array_palindrom_1 = ["Prani", "NAN", "101", 111, "nil"]
store_reverse = [];
ans = [];
let Is_panlindrom_arrow = array_palindrom => {
    for (let i in array_palindrom) {
        store_reverse = String(array_palindrom[i]).split("").reverse().join("");
        if (array_palindrom[i] == store_reverse) {
            ans.push(store_reverse)
        }
        else {
            continue;
        }
    }
    return ans;
}
console.log(Is_panlindrom(array_palindrom_1))
//Return median of two sorted arrays of same size-----------------------------------------------------------
console.log("%cReturn median of two sorted arrays of same size", style)
console.log("%cInput [4,2,3,5,1] AND [6,7,9,8,11]",input)
//1.anonymous function
console.log("1.anonymous function")
let array_1 = [4, 2, 3, 5, 1]
let array_2 = [6, 7, 9, 8, 11]
ans = []
let median;
let median_function = function (array1, array2) {
    if (array2.length == array1.length) {
        array1 = array1.sort(function (a, b) { return a - b });
        array2 = array2.sort(function (a, b) { return a - b });
        ans = array1.concat(array2);
        return ans.length % 2 !== 0 ? ans[ans.length / 2] : (ans[(ans.length / 2) - 1] + ans[ans.length / 2]) / 2
    }
    else {
        return "size of two array should be same"
    }
}
console.log(median_function(array_1, array_2))
//2.arrow function
console.log("2.arrow function")
array_1 = [4, 2, 3, 5, 1]
array_2 = [6, 7, 9, 8, 11]
ans = []
median = 0;
let median_function_arrow = (array1, array2) => {
    if (array2.length == array1.length) {
        array1 = array1.sort(function (a, b) { return a - b });
        array2 = array2.sort(function (a, b) { return a - b });
        ans = array1.concat(array2);
        return ans.length % 2 !== 0 ? ans[ans.length / 2] : (ans[(ans.length / 2) - 1] + ans[ans.length / 2]) / 2
    }
    else {
        return "size of two array should be same"
    }
}
console.log(median_function_arrow(array_1, array_2))
//Remove duplicates from an array-------------------------------------------------------------------------
console.log("%cRemove duplicates from an array", style)
console.log("%cInput [1,2,,3,3,4,5,6,7,8]",input)
//1.anonymous function
console.log("1.anonymous function")
let redundeant_array = [1, 2, 3, 3, 4, 5, 6, 7, 8, "1", 2, "1"]
ans = []
let uniquevalues = function (redundeant_array) {
    ans = [...new Set(redundeant_array)];
    return ans;
}
console.log(uniquevalues(redundeant_array))
//2.arrow function
console.log("2.arrow function")
redundeant_array = [0, 0, 0, 0, 023, 2, 3, 3, 4, 5, 6, 7, 8, "1", 2, "1"]
ans = []
let uniquevalues_arrow = (redundeant_array) => {
    ans = [...new Set(redundeant_array)];
    return ans;
}
console.log(uniquevalues_arrow(redundeant_array))
//Rotate an array by k times and return the rotated array
console.log("%cRotate an array by k times and return the rotated array", style)
console.log("%cInput [1, 2, 3, 4, 5, 6]",input)
//1.anonymous
console.log("1.anonymous function")
let array_new = [1, 2, 3, 4, 5, 6]
const rotateArray = function (arr, k) {
    return arr.concat(arr).slice(k, k + arr.length);
}
console.log(rotateArray(array_new, 1))
//arrow function
console.log("2.arrow function")
array_new = [1, 2, 3, 4, 5, 6]
const arrow_rotate = (array, k) => array.concat(array).slice(k, k + array.length)
console.log(arrow_rotate(array_new, 1))